<template>
  <div>
    <h1>Danh sách Đơn hàng</h1>
    <!-- Bảng đơn hàng -->
  </div>
</template>

<script>
export default {
  name: 'OrderList'
}
</script>
<template>
  <div>
    <h1>Trang quản trị</h1>
  </div>
</template>

<script>
export default {
  name: 'DashboardView',
}
</script>
<template>
  <div>
    <h1>Danh sách tin tức</h1>
    <!-- Bảng danh sách tin tức -->
  </div>
</template>

<script>
export default {
  name: 'NewsList'
}
</script>
<template>
  <div>
    <h1>Danh sách khách hàng</h1>
    <!-- Bảng danh sách khách hàng -->
  </div>
</template>

<script>
export default {
  name: 'CustomerList'
}
</script>
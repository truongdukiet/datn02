<template>
  <div>
    <h1>Danh sách voucher</h1>
    <!-- Bảng danh sách voucher -->
  </div>
</template>

<script>
export default {
  name: 'VoucherList'
}
</script>
<template>
  <div>
    <h1>Sản phẩm yêu thích</h1>
    <!-- Danh sách sản phẩm yêu thích -->
  </div>
</template>

<script>
export default {
  name: 'FavoriteProductList'
}
</script>
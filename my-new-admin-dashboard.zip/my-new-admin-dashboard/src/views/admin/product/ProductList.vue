<template>
  <div>
    <h1>Danh sách Sản phẩm</h1>
    <!-- Bảng sản phẩm -->
  </div>
</template>

<script>
export default {
  name: 'ProductList'
}
</script>
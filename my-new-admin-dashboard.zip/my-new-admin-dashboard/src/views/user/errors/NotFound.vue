<template>
  <div class="not-found">
    <h1>404 - Không tìm thấy trang</h1>
    <router-link to="/">Quay về trang chủ</router-link>
  </div>
</template>

<script>
export default {
  name: 'NotFound'
}
</script>